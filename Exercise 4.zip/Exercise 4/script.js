//4.Given a positive integer. Bring the last digit of the number to the beginning. Print the new  number. If the last digit of the inserted number is 0, number remains the same.
var a = 367;
var b = a % 10;
var c = ((a-(a % 10)) / 10);
var d = "" + c;

if (a % 10 == 0){
   console.log(a);
} else if (a < 10){
   console.log(a);
} else{
   console.log(b+d);
}


var a = 1002;
var b = a % 10;
var c = ((a-(a % 10)) / 10);
var d = "" + c;

 if (a % 10 == 0){
   console.log(a);
} else if (a < 10){
   console.log(a);
} else{
   console.log(b+d);
}



var a = 250;
var b = a % 10;
var c = ((a-(a % 10)) / 10);
var d = "" + c;

if (a % 10 == 0){
   console.log(a);
} else if (a < 10){
   console.log(a);
} else{
   console.log(b+d);
}

var a = 8;
var b = a % 10;
var c = ((a-(a % 10)) / 10);
var d = "" + c;

if (a % 10 == 0){
   console.log(a);
} else if (a < 10){
   console.log(a);
} else{
   console.log(b+d);
}


