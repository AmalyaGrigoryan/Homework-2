//13.  Enter a number. Find the difference between its biggest and smallest digits    

var a = 5;
var b = 0;

if((a >=1) && (b>=1)){
    console.log(a -b);
}else{
    console.log(0);
}

var a = 152;
var b = (a % 1000);
var y = ((b-(a % 100))/100);
var b1 = (a % 100);
var y1 = ((b1-(b1 % 10))/10);
var b2 = (a % 10);
var y2 = b2;

if((y > y1) && (y > y2) && (y1 < y2)){
    console.log(y - y1);
}else if(((y > y1) && (y > y2) && (y2 < y1))){
    console.log(y - y2);
}else if((y1 > y) && (y1 > y2) && (y < y2)){
    console.log(y1 - y);
}else if((y1 > y) && (y1 > y2) && (y2 < y)){
    console.log(y1 - y2);
}else if ((y2 > y) && (y2 > y1) && (y1 < y)){
    console.log(y2 - y1);
}else{
    console.log(y2 - y);
}


var a = 4593653;
var b = (a % 10000000);
var y = ((b-(a % 1000000))/1000000);
var b1 = (a % 1000000);
var y1 = ((b1-(b1 % 100000))/100000);
var b2 = (a % 100000);
var y2 = ((b2-(b2 % 10000))/10000);
var b3 = (a % 10000);
var y3 = ((b3-(b3 % 1000))/1000);
var b4 = (a % 1000);
var y4 = ((b4-(b4 % 100))/100);
var b5 = (a % 100);
var y5 = ((b5-(b5 % 10))/10);
var b6 = (a % 10);
var y5 = b6;
var max;
var min;
