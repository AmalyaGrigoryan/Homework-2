//3.   Given number  n  (positive integer). Print the value of  n + nn + nnn (not multiplication)  .

var n = 3;
var nn =  n + n;
var nnn = n + n + n; 

if (n > 0 ){
    alert(""+ n + "" + nn + "" + nnn);
}else {
    alert("Please enter a positive number");

}

var n = 17;
var nn =  n + n;
var nnn = n + n + n; 

if (n > 0 ){
    alert(""+ n + "" + nn + "" + nnn);
}else {
    alert("Please enter a positive number");

}


var n = 100;
var nn =  n + n;
var nnn = n + n + n; 


if (n > 0 ){
    alert(""+ n + "" + nn + "" + nnn);
}else {
    alert("Please enter a positive number");

}


// var n = prompt("please enter a number");
// var nn =  n + n;
// var nnn = n + n + n ; 


// if (n > 0 ){
//     alert( n  + "" + nn + "" + nnn) ;
// }else {
//     alert("Please enter a positive number");

// }


