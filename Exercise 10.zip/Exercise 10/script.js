//10.Insert a digit and a number. Check whether the digits contains in the number or not.  

var a = 5;
var b = 2463;

var y = b % 10000;
var z = ((y-(y % 1000))/1000);
var y1 = b % 1000;
var z1 = ((y1-(y1 % 100))/100);
var y2 = b % 100;
var z2 = ((y2-(y2 % 10))/10);
var y3 = b % 10;
var z3 = y3;

if((a == z) ||(a == z1) || (a == z2) || (a == z3)){
    console.log("Yes");
}else {
    console.log("No");
}

var a = 4;
var b = 6;

var y = b % 10;
var z = y;

if(a == z) {
    console.log("Yes");
}else {
    console.log("No");
}



var a = 8;
var b = 45689;

var y = b % 100000;
var z = ((y-(y % 10000))/10000);
var y1 = b % 10000;
var z1 = ((y1-(y1 % 1000))/ 1000);
var y2 = b % 1000;
var z2 = ((y2-(y2 % 100))/100);
var y3 = b % 100;
var z3 = ((y3-(y3 % 10))/10);
var y4 = b % 10;
var z4 = y4;

if((a == z) ||(a == z1) || (a == z2) || (a = z3) || (a == z4)){
    console.log("Yes");
}else {
    console.log("No");
}

