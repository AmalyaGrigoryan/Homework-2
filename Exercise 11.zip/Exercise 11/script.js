//11.  Enter a number. Reverse its first and last digits. Print the new number.    

var a = 2;
var b = a % 10;
console.log(b);

var a = 13;
var b = a % 10;
var y = ((a-(b % 10))/10);
console.log("" + b + y);

var a = 895796;
var b = a % 1000000;
var y = ((b-(b % 100000))/100000);
var b1 = a % 100000;
var y1 = ((b1-(b1 % 10000))/10000);
var b2 = a % 10000;
var y2 = ((b2-(b2 % 1000))/1000);
var b3 = a % 1000;
var y3 = ((b3-(b3 % 100))/100);
var b4 = a % 100;
var y4 = ((b4-(b4 % 10))/10);
var b5 = a % 10;
var y5 = b5;
console.log("" + y5 + y4 + y3 + y2 + y1 + y);
