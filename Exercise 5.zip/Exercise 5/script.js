//5.Given five numbers as input. 
 //Calculate and print the average of the numbers(without  using arrays).

//  var prompt1 = prompt("Please enter 1st number");
// var prompt2 = prompt("Please enter 2nd number");
// var prompt3 = prompt("Please enter 3rd number");
// var prompt4 = prompt("Please enter 4th number");
// var prompt5 = prompt("Please enter the last number");
// var prmset = prompt1 + prompt2 + prompt3 + prompt4 + prompt5;

// if(prmset === Number){
//     alert(prmset/5);
// }else{
//     
// }

var a = 45;
var b = -12;
var c = 0;
var d = 3;
var e = -15;
var f = a + b + c + d + e;
console.log(f/5);


var a = 7;
var b = 52;
var c = -23;
var d = 9;
var e = -81;
var f = a + b + c + d + e;
console.log(f/5);