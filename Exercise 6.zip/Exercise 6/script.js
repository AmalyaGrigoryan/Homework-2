//6.Given three numbers. Sort them by the ascending order

var a = 45;
var b = 26;
var c = 78;

if(a < b && a < c && b < c){
    console.log( a, b, c);
}else if(a < b && a < c && c < b){
    console.log(a, c, b);
}else if(b < a && b < c && a < c){
    console.log(b, a, c);
}else if(b < a && b < c && c < a){
    console.log(b, c, a);
}else if(c < a && c < b && a < b){
    console.log(c, a, b);
} else if(c < a && c < b && b < a){
    console.log(c, b, a);
}

var a = -23;
var b = -456;
var c = 0;

if(a < b && a < c && b < c){
    console.log( a, b, c);
}else if(a < b && a < c && c < b){
    console.log(a, c, b);
}else if(b < a && b < c && a < c){
    console.log(b, a, c);
}else if(b < a && b < c && c < a){
    console.log(b, c, a);
}else if(c < a && c < b && a < b){
    console.log(c, a, b);
} else if(c < a && c < b && b < a){
    console.log(c, b, a);
}
