//1.  Given two numbers print 1 if one of them is divisible by the other one, otherwise print 0.  
var number = prompt("Please enter a number");
var a = prompt("Please enter second number");
 
if (number % a == 0 || a % number == 0){
    alert("1");
}else {
    alert("0");

}

