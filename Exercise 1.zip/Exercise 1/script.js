//1. Given a number. Print “odd” if the number is odd and “even” if it’s even.  
var number = prompt("Please enter a number") 

if (number % 2){
    alert("The namber is Odd");
}else {
    alert("The number is Even");

}