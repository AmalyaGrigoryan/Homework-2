//12.Write a program which will compute the area of a rectangular or a triangle after
//  prompting the user to type the name of the figure name. 
//Also check that entered  numbers are positive.   For the triangle entered numbers are height and and base.     

var a = prompt("Please enter the geometrical body name");
var b = prompt("Please enter one part size");
var c = prompt("Please enter the other part size");
var d = "triangle";
var e = "rectangle";

if((a === d) && (b >= 1) && (c >= 1)){
    alert("Square of the triangle is :" + ((b * c)/2));
}else if((a === e) && (b >= 1) && (c >= 1)){
    alert("Square of the rectangle is: " + (b * c));
} else {
    alert("Please enter only positives");
}
